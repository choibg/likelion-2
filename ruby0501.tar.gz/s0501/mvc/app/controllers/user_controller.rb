class UserController < ApplicationController
  def login
  end 
end

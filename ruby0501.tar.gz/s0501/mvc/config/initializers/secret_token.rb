# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Mvc::Application.config.secret_token = 'a883f578a1de8d9560dd04421a4671487fe4fbc653b5320020760bd186c73de53078816d0be7ea8dcd80a342d8f85d919f522a778b5da7ece4425d1e123162f2'

# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Gmail::Application.config.secret_token = 'c6090148af99212249a01ce8389d059892072d067d867c5e2b75885b5351dd9014de81320c2e45ddae0cac79c9de5a2d93224ce5b02c915cec02c281b139365d'

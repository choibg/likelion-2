module MailHelper
end

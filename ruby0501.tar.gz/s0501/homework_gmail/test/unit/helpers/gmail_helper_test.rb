require 'test_helper'

class GmailHelperTest < ActionView::TestCase
end

file=File.open("some_file.txt", "r") 
a=file.gets
puts a 


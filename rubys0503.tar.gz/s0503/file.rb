file=File.open("some_file.txt", "w")
file.puts("Hello world!")


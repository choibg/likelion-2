require 'test_helper'

class MajorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

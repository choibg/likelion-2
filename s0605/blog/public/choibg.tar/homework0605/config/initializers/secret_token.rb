# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Homework0605::Application.config.secret_token = '3d205bb2e6f7d15fd1f097a534eea403292a3c8a40acb5cb71f35a5dcb339abda21f310cf05a3ba90ec67d34814ab82c85750a756cd688447bfff87e511644f3'

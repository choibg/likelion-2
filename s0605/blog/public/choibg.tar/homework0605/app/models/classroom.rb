class Classroom < ActiveRecord::Base
  # attr_accessible :title, :body
  has_many:qrstrings
  has_many:lectures, :through =>:timetables
end

class Attendance < ActiveRecord::Base
  # attr_accessible :title, :body
  belongs_to:qrstring 
  belongs_to:user
  belongs_to:timetable
end

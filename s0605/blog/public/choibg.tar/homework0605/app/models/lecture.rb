class Lecture < ActiveRecord::Base
  # attr_accessible :title, :body
  has_many:users, :through =>:registraion
  belongs_to :classromm 

end

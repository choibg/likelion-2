class User < ActiveRecord::Base
  # attr_accessible :title, :body
  belongs_to:major 
  has_many:lectures, :through => :registration
  has_many:attendances
end

class Qrstring < ActiveRecord::Base
  # attr_accessible :title, :body
  belongs_to:classroom
end

class Timetable < ActiveRecord::Base
  # attr_accessible :title, :body
  belongs_to:lecture
  belongs_to:classroom 
  has_many:attendances
end

class CreateQrstrings < ActiveRecord::Migration
  def change
    create_table :qrstrings do |t|
      t.integer:classroom_id, null =>false
      t.string:qrcode
      t.timestamps

    end
  end
end

class CreateRegistrations < ActiveRecord::Migration
  def change
    create_table :registrations do |t|
      t.integer:user_id, null=>false
      t.integer:lecture_id, null=>false

      t.string :registration_time
      t.timestamps

    end
  end
end

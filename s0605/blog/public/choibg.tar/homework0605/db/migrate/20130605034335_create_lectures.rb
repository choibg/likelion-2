class CreateLectures < ActiveRecord::Migration
  def change
    create_table :lectures do |t|
      t.integer:classroom_id, null =>false
      t.string :lecture_name
      t.integer:lecture_starttime
      t.integer:lecture_latetime
      t.integer:lecture_endtime

      
      t.timestamps
    end
  end
end

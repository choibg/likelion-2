class CreateClassrooms < ActiveRecord::Migration
  def change
    create_table :classrooms do |t|
      t.integer:building_number 
      t.integer:classroom_number

      t.timestamps
    end
  end
end

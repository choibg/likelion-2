class CreateAttendances < ActiveRecord::Migration
  def change
    create_table :attendances do |t|
      t.integer:attendance_time
      t.integer:user_id, null=>false
      t.integer:qrstring_id, null=>false
      t.integer:timetable_id, null=>false

      t.timestamps
    end
  end
end

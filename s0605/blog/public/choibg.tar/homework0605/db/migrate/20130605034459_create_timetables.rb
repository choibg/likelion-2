class CreateTimetables < ActiveRecord::Migration
  def change
    create_table :timetables do |t|
      t.integer:lecture_id, null => false
      t.integer:classroom_id
      t.string:lecture_timetable_name

      t.timestamps

    end
  end
end

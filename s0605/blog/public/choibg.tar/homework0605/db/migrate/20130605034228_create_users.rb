class CreateUsers < ActiveRecord::Migration
  def change
    create_table :users do |t|
      t.integer :major_id, null=>false     
      t.string :user_name
      t.string :user_passsword
      t.sting :realname
      t.string :student_number
      t.string :email

      

      t.timestamps
    end
  end
end

# TODO

## RailsUtil

* provide a :validate_access_token or so option
* test for rails util for writing cookie

## RestGraph

* error_handler can't be turned off
* more docs?
* more examples?

# encoding: utf-8

Rainbows! do
  use :EventMachine
end

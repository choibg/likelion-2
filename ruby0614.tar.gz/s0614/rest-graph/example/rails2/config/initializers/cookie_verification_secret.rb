# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '095e8e5c0b6b901901efb23fab50005b68d9d6a9d41f4ec780946cff34b26603762bc0ea1baf204613b252e5ae499d38b232d5b75edac513a723e450e76548a3';

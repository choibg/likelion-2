
require 'rest-graph/core'

RestGraph::VERSION = '2.0.3'

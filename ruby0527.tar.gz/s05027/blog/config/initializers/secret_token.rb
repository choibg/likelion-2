# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Blog::Application.config.secret_token = '034b521e0c78e00aa07994b1e4a458fe9d3eb7f887512aa154d1a2c47a9a287b480413ef45b88c0e7eb2ebfa788f2cd4807f26c3c98484c6d8c6d0a1d143e319'

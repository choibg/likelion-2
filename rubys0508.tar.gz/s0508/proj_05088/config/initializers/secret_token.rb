# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Proj05088::Application.config.secret_token = 'ef37401b5b573e3194a206ecc86ae34004bec1ff31a0e9faea348fbeda367c0e3f74c3707e854a93a51eae28215b5f237680b6159f7788ccf2705166d6a3b1ee'

1.upto(1000) do |x|
  if (x%3==0 and x%5==0)
    puts x 
  end 
end

puts "hello world"
a=1
if a==1
  puts "a is 1"
else
  puts "a is not 1"
end
puts "end"

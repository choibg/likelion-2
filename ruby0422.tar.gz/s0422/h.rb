puts "start"
0.upto(1000) do |x|
  puts x
end
puts "end..."


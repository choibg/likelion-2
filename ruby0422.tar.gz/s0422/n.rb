x=0
while x<100
  x=x+1
  puts x 
end
puts x

a=2
if a==1
  pust "a is 1"
elsif a==2
  puts "a is 2"
elsif a==3
  pust "a is 3"
else
  puts "a is not 2"
end

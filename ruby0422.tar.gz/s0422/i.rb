a=10%3
puts a

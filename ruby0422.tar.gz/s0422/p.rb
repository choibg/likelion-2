a=1
b=1
  puts a
  puts b
while(b<100)
    c=a+b
    a=b
    b=c
    puts c
end

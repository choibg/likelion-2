x=0
while x<100
  puts x 
end
puts x

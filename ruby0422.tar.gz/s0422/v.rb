a=[1,1,1,5,5,3,2,5,9]
puts a.uniq

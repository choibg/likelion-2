0.upto(3) do 
  puts "hi"
end

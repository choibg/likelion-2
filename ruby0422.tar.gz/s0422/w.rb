a=["haeun","aehuin"]
a.each do |x|
  puts "hi" + x
end


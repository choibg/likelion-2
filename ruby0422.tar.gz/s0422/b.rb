is="hello world"
is=1
is=is+1
puts is 


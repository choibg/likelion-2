puts "hello world"
a="hello world"
puts a 

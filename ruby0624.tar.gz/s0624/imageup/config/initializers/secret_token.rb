# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Imageup::Application.config.secret_token = 'f1b954dc4111f12fb6ae212ff8aa7252c4a1469722f0927fcf5ec78b75e0a6aefa7fa2470ec45f4af10deb884b702212fd8eb9f88b96c483a44831ccadebe459'

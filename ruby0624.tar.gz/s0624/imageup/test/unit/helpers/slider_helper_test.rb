require 'test_helper'

class SliderHelperTest < ActionView::TestCase
end

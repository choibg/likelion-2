require 'test_helper'

class PhotodbTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

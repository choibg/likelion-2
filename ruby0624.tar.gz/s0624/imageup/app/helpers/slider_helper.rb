module SliderHelper
end

require 'test_helper'

class MyphoneTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Phone::Application.config.secret_token = '2412e1beead2dd0df659f95ac9344f1f773c393a6ec4dc826242d2e2c145e4eb62fb7b3f0fdfa3f16acadf27888b6cc9e2ae90d864d388ceef95f98a3c45f340'

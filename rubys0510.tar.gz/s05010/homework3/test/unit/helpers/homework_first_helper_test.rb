require 'test_helper'

class HomeworkFirstHelperTest < ActionView::TestCase
end

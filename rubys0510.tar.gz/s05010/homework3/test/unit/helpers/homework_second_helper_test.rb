require 'test_helper'

class HomeworkSecondHelperTest < ActionView::TestCase
end

# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Consol::Application.config.secret_token = '821dc0707b47fd871259bdfc6b09885d83419b0a32d0b6ca35582e049b59c59c8c7c85061a5744e569c9e57547d8aa6bbdac8c757ca24890d158e971a5eec54b'

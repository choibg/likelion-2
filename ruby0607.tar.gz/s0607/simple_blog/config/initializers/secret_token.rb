# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SimpleBlog::Application.config.secret_token = 'f071562ac184c46354d4cc9cdafa8944ce0a1507b10164938aef92a57a558ddbd5db4abc1d8b28640d29d1dd89c80ce3a03f62ec6154725c5d8ebc5740ec09a3'

#encoding: utf-8
class BlogController < ApplicationController
  def index
    @posts = Post.all  #모든 포스트(글)를 다 긁어옵시다!
  end

  def update
    @post = Post.find(params[:id]) #업데이트 할 글을 뽑아옵시다.
  end

  def write_process #새 글을 쓰는 액션(함수)입니다.
    post = Post.new #새 글을 하나 new 메소드로 만들고, post라는 변수에 저장합시다.

    #post.username, post.content에서 username, content는 db/migrate에 Post 모델에 정의했습니다.
    post.username = params[:username_from_view] #params로 받은 정보를 각자 맞춰서 잘 저장하고
    post.content = params[:content_from_view]
    saved = post.save                                   #save 명령어로 저장!
    if saved == false 
      msg =""
      post.errors.each do |x,y|  #에러메세지는 항상 pair로 묶여 있습니다. 그래서 어떤 변수 (x)에 어떤 에러(y)가 났는지 #를 보여줍니다. 
      msg<<y #그런데 우리는 어떤 변수에 문제가 생겼는지는 아직 알게 없으니까, 그냥 y값만 뽑아냅시다.  
    #위의 식은 post.errors.each {|x,y| msg<<y}이렇게 써도 됩니다. 
      end
      flash[:notice]=msg 
        redirect_to :action =>'index'
      else
      redirect_to :action => 'index'
     end 
  end

  def update_process #write_process랑 크게 다르지 않습니다.
    post = Post.find(params[:id])
    post.username = params[:username_from_view]
    post.content = params[:content_from_view]
    post.save

    #You don't have to make view file(update_process.html.erb) in view directory by this redirction
    redirect_to :action => 'index' 
  end

  def reply_process
    reply = Comment.new
    reply.post_id = params[:id]
    reply.username = params[:reply_username_from_view]
    reply.content = params[:reply_content_from_view]
    reply.save

    #You don't have to make view file(update_process.html.erb) in view directory by this redirction
    redirect_to :action => 'index' 
  end

  def delete_post
    post = Post.find(params[:id])
    post.destroy
    redirect_to :action => 'index' 
  end
end

class UserController < ApplicationController

  def join
  
  end
  
  def join_process
    u =User.new
    u.username = params[:username]
    u.realname = params[:realname]
    u.passwd = params[:passwd]
    u.phone_number = params[:phone]
    u.save 

    redirect_to :controller =>'user', :action => 'join'

  end



  def login_process
    u = User.find_by_username(params[:username])
      if u.nil?


        redirect_to :controller => 'blog', :action =>'join' 
      elsif u.passwd == params[:passwd]
        session[:user]=u

        redirect_to :controller => 'blog', :action =>'index'
      else
        redirect_to :controller => 'blog', :action =>'join'
      end
    end
    def logout 
      reset_session
        redirect_to :controller => 'blog', :action =>'join' 
    end


end

a=Hash.new 
a["height"]=10
a["weight"]=200
puts a["weight"]


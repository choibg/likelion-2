a=1
if a==1
  puts "hi"
elsif a==2
  puts "bye"
else
  puts "kk"
end 

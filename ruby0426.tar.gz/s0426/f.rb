def put_number input 
  puts input
end
1.upto(15) do |x|
  put_number x 
end 


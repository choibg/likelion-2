1.upto (100)do 
  puts "hi"
end


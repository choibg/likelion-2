a=1
if a==1
  puts "hi"
else
  puts"bye"
end 


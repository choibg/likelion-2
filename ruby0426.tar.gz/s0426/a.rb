a=Array.new
a<<1
a<<2
a<<3
puts a.size


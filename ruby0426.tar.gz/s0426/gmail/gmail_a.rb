require 'gmail'
def send_mail(email)
  gmail=Gmail.connect("choibg0417@gmail.com","xxxxxxxxxx")
    gmail.deliver do
      to email 
      subject "This is a email from my ruy code" 
      html_part do 
        content_type 'text/html;chareset=UTF-8'
        body "<p>Text of <em>html</em> message</p>"
      end
    end
  gmail.logout 
end 
send_mail "xvxvxvooo@naver.com"
send_mail "choibg0417@gmail.com"

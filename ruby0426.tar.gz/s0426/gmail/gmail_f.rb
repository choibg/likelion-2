require 'gmail'
  def send_mail(email, name)
    gmail=Gmail.connect("choibg0417@gmail.com", "xxxxxxxxxxx")
    gmail.deliver do 
      to email
      subject "hello"
      text_part do 
        body "Hi, #{name}"
      end
    end
    gmail.logout
  end
a=Hash.new
a["BG"]="xvxvxvooo@naver.com" 
a["choibg"]="choibg0417@gmail.com"
a.each do |x,y|
  send_mail(y,x)
end 

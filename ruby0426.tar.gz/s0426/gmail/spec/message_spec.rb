require 'spec_helper'

describe "A Gmail message" do
  context "on initialize" do
    it "should set uid and mailbox" do
      pending
    end
  end
  
  context "instance" do
    it "should be able to mark itself as read" do
      pending
    end
    
    it "should be able to mark itself as unread" do
      pending
    end
    
    it "should be able to set star itself" do
      pending
    end
    
    it "should be able to unset start" do
      pending
    end
    
    it "should be able to archive itself" do
      pending
    end
    
    it "should be able to delete itself" do
      pending
    end
    
    it "should be able to move itself to spam" do
      pending
    end
    
    it "should be able to set given label" do
      pending
    end
    
    it "should be able to mark itself with given flag" do
      pending
    end
    
    it "should be able to move itself to given box" do
      pending
    end
  end 
end

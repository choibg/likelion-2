require 'gmail'
  def send_mail(email,title,text)
    gmail=Gmail.connect("choibg0417@gmail.com", "xxxxxxxxx")
      gmail.deliver do 
        to email
        subject title
        text_part do
          body text
        end
      end
    gmail.logout
  end
print "Email:"
email=gets.chomp
print "subject:"
title=gets.chomp
print "Content:"
text=gets.chomp
send_mail(email,title, text)


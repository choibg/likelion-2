module Gmail
  VERSION = "0.4.0"  
end # Gmail

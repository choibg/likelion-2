require 'gmail'
  def send_mail(email,dear)
    gmail=Gmail.connect("choibg0417@gmail.com", "xxxxxxxxx")
    gmail.deliver do
      to email
      subject "This is a email from my ruby code"
      text_part do
        body "Dear.. #{dear}"
      end
    end
    gmail.logout 
  end
email_list=[["choibg0417@gmail.com","choibg"],["xvxvxvooo@naver.com","bg"],["xvxvxvooo@nate.com","hello"]]
email_list.each do |x| 
  send_mail x[0], x[1]
end 


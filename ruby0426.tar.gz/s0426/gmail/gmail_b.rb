require 'gmail'
  def send_mail(email)
    gmail=Gmail.connect("choibg0417@gmail.com", "xxxxxxxxxxx")
      gmail.deliver do 
        to email 
          subject "This is a email from my ruby code" 
          html_part do 
            content_type 'text/html;charset=UTF-8'
            body "<p>Text of <em>html</em> message </p>"
          end
        end
     gmail.logout
  end
  email_list=["choibg0417@gmail.com", "xvxvxvooo@naver.com", "xvxvxvooo@nate.com"]
  email_list.each do |x|
    send_mail x 
  end 



# TODO

* Specs for xoauth 
* Specs for message operations
* Specs for filters in mailbox
* Specs for current [Gmail IMAP extensions](http://code.google.com/apis/gmail/imap/)
* Non-English accounts
* Further implement [Gmail IMAP extensions](http://code.google.com/apis/gmail/imap/)
  * add custom search (X-GM-RAW)
  * add thread id (X-GM-THRID)
* Export/Import to mbox format
* Integration with [contacts](http://rubygems.org/gems/contacts) gem
require 'gmail'
gmail=Gmail.connect("choibg0417@gmail.com", "xxxxxxxxx")
  gmail.deliver do
    to "xvxvxvooo@naver.com"
      subject "hello" 
      html_part do 
        content_type 'text/html;charest=UTF-8'
        body "<p>Text of <em>html</em> message</p>" 
      end 
    end
  gmail.logout 

  

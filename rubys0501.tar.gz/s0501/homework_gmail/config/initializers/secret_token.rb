# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
HomeworkGmail::Application.config.secret_token = '8758f41d58d24101f2190548be281fda39c3644a25783c8e159f7a2e3649db4f4fe3a49fdd0bbba05d3dff64c8541c9c69bdc6b1f27d120ab8f81104c33623c4'

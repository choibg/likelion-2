require 'test_helper'

class MailHelperTest < ActionView::TestCase
end

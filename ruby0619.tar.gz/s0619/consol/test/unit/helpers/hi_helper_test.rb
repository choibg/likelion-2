require 'test_helper'

class HiHelperTest < ActionView::TestCase
end

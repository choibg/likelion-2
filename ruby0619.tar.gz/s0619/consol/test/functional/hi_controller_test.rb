require 'test_helper'

class HiControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end

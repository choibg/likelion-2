# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Consol::Application.config.secret_token = '0131091a2fcb0f816ca04cfc1686f832e826a08628e2a66f825a512b3f570525a84f2369f108c7f49e06ec632d83df5d0fb99d230234f282a000e5f373ee7398'

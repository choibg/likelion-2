# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Project::Application.config.secret_token = 'aa243bf18fc3015a174270abaa2ac5901f23d1381ccd89c22b5ea00d9bb39875e21bc9ee16cb82d2957cd10d5807685976d1f1d9d58e0ef3638e595d658eef21'

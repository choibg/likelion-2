require 'test_helper'

class CommentHelperTest < ActionView::TestCase
end

require 'test_helper'

class CommentControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end

# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Tinymce::Application.config.secret_token = '86230ec0b633bc2dfa9b55aca90dabe6c8281e8a3929e27c40c7168b46a3a2837bcb59f0a67db821343bab67e049230892b6e3189c19333e6d499695d5467365'

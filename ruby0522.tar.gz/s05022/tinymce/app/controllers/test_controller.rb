class TestController < ApplicationController
  def index
  end 
  
end

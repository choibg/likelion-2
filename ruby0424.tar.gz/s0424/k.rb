while true
  print "Enter your name:"
  a=gets 
  puts "hi" + a
end

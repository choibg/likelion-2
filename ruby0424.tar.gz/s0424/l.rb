def plus_two
  b=gets
  return b.to_i+2
end
while true
  e=plus_two
  puts e
end 

puts "hi" #화면에 hi를 출력한다. 
=begin 
아래부터 쭉 주석이다. 
하이
헬로
안녕
=end
puts "hello world"

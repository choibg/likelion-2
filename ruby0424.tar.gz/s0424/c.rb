a=Array.new
a<<3
a<<4

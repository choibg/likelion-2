def plus_two(a,b)
  return a+b 
end
def minus_two(q,w) #인자를 중복되지 않게 맞추어야 한다. 
  return q-w
end
e=plus_two(1,2)
f=minus_two(4,3)
puts e
puts f 

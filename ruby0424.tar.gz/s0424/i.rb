def plus_two
  b=gets.chomp.to_i
  return b+2
end
e=plus_two
puts e

a=Hash.new 
  a["name"]="kilho"
  a["age"]=26
  a["gender"]="male"
puts a 


def plus
  puts 3+4
end 
puts "hi"
plus


a=["charles", "princess", "juminlee"]
a.each do |x|
  puts "hi" + x 
end


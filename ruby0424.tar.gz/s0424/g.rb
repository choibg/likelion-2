def plus(a,b)
  return a+b
end
return_value=plus(3,4)
puts return_value


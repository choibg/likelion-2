while true 
  a=gets
  puts "hi" +a
end 

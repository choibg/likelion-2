def plus(a,b)
  puts a+b
end
plus(3,4)


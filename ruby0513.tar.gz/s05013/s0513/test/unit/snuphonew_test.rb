require 'test_helper'

class SnuphonewTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

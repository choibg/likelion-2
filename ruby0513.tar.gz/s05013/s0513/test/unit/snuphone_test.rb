require 'test_helper'

class SnuphoneTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

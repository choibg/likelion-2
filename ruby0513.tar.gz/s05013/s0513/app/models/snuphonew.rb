class Snuphonew < ActiveRecord::Base
  # attr_accessible :title, :body
end

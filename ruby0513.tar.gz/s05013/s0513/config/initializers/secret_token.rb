# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
S0513::Application.config.secret_token = '99abbb596648deb7bc3d2cbe64707fda1da72eb72c34d2c001e350babe2ccb64fd9e8eb0c0cf96e2c498d5e8113451c9e3d4cf8bdc68e683f5ab0afcbdb4eb25'

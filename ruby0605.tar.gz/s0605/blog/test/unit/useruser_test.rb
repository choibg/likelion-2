require 'test_helper'

class UseruserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

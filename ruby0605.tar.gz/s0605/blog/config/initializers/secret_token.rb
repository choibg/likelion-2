# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
B::Application.config.secret_token = 'ac53ec4ffa0b3a24616e660c8db63a5b3f14304b74426f401760bba12c49cff7dceb0589d297a2888f6650c2c29cc5c516cfcd72cc0b8eafcf7b65a3ea3b0b63'

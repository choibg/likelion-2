require 'json'
data = {
  :myname => "Duhee Lee",
  :weight => "63kg"
  }

  puts data.to_json 

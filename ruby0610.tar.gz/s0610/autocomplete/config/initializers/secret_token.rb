# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Autocomplete::Application.config.secret_token = 'd1e8ab8d42d82e79ce9c3372de79e3e010426aff4a47b87f64cda637110331eb098e578f10627b319804c53a1398f9ceede740f2f03a20a6baeac4deccd7edd5'

1.upto(30){ |x| puts ("*"*x)} 


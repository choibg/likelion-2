# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Blog::Application.config.secret_token = '8193dd91b9b37ee4975c5f52cfc4ec5913301e23dce9158308fb61945da5b4c06715de6285a8063e2adc75347ca60c2d2a934775520c3a884c9e66298644c315'

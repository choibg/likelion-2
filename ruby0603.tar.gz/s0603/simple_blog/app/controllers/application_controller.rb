class ApplicationController < ActionController::Base
# protect_from_forgery
  before_filter :get_user
  def get_user 
    @user = nil
      if !session[:user_id].nil?
        @user =User.find(session[:user_id])
      else
        redirect_to :controller =>'user', 'action' =>'login_form'
      end
  end

end

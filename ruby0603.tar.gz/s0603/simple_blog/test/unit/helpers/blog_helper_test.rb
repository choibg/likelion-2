require 'test_helper'

class BlogHelperTest < ActionView::TestCase
end

# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Asdf::Application.config.secret_token = 'f32b1672d875af20fdb9e904c02b30fc1d12ef008ac533d97dd49ebff58816069bfe18d7956b9032bcc87ffe0b5824561a8020ba415656eacefc4a7242f7bba4'
